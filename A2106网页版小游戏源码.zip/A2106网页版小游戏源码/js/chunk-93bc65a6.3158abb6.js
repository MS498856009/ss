(window["webpackJsonp"] =111111 window["webpackJsonp"] || []).push([
	["chunk-93bc65a6"], {
		"16de": function(t, s) {
			t.exports =
				"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAAAXNSR0IArs4c6QAABaFJREFUeF7tndF53CAQhKETp5O4ksSVxFeJ3YndSdwJ+Uh0PuV8Oq2AWRZ29OIHA5KY/1bMglAMPFz3QHR997z5QACcQ0AACIDzHnB++4wABMB5Dzi/fUYAJQBSSi8hhI8Y40nplKLTEABRN5UXSik9hBCy+N+XVp4tQUAAyrXdrbmI/xZCyBCsDzMQEIBdGcsKpJTyLz6Lv3W8xxgfy1pvV4sAtOvLz5YE4p/LfoQQHmOM+W+XgwA07vaU0s/lmS9tuSsEBEAqk6BcSulXCOFZUPS6SDcICECBWreqpJTy8/480i9pNUNwijG+llQurUMASntuVa+B+OsxgSoEBKACgBsev6K1v1VzFHiKMb7XNiStTwCkPXVV7o7HL2xRX/x8oQSgQK4DNk/aerecAAGQSrSUm0l8RoDj4h/1+HtneI0xPu0VQv6fEUDYuxUef+sMJuYDCIAAgIY273y2PNJX9ftbt0kAdgAAiJ9z/2o2b49vArDRQzN4/D3xOQi8L/5vSQcKy6gneITXxTzAdUcBbF5eBvZNKoh2OT4CVj0OEL9bgkcKEgG4JHhae3zz4nMMcBG/dB5/64fWPcHDCCDsAYDNM+PxJV3g+hEAEN+UxycAeh4/n2k48V2OAZYEjwuPzwhw1QMAm9dtMadEXEkZN2MAgPhD2Lw9CFwAULBWf6/fphDfxRhgeSs3J3laHcN4fMkNTx0BADbPxCIOibDSMtMCABB/qASPWwAA8/jDenwJBFNFAHp8ieT/l5kGAIDNM7uI47jM2zWmAAAhvuVFHARg1QP0+HU4DB0BAB5/mgSPFIthAQDYvKkSPNMCALJ5U3p8CQRDRQCQ+EPO40vElZQZBgCAx586wSMRf5jJIITN096JQyqIdjnzEQAhvhePL4HJNAD0+BIJ68qYBYAev05YaW2TANDjS+WrL2cKAJDNm24RR73slxbMAAAS37XHl4BiAgB6fIlUmDLdAUDYPHp8OSxdAaD4cqFQJbsBANh2zd1UbgsougBAj99CujZtqANAj99GuFatqAIAEJ8ev5IENQAA26vnWycAowCQr5MQVKoFqK4WAc7XvkDwo/DjSltdwEhQCIc6AKtI0BoCl4s6C3X/rNYFgFU0aL09m+ldOWvFQtTvCsASDZpD0PtrnAihUG12B2CBYO87u0fvf/i9e47ecGl5EwCAHIKLlztLhT/XMwMAEII8ODzVdtSs9U0BQAj0MTMHANAmMldwgy+TAAAhYK7gCgKzADBXoPM4MA8AcwVYEIYAgLkCHATDAAB0CKqfa8dJWdbyUAAAIXCbKxgOgBUELyGEnEJuceSsoUsIhgQAaBPd5QqGBYAQtAh8YY4vhwLeMXCTMBo6Aqx/AwAIXEwpTwPA6pHQ+oNQ+Q3jDMOUx1QAAG3itBBMBwAQglOM8XW2MDAlAMwVyDGdFgDaRBkEUwNACPYhmB6AcxcAbOIUuQI3ACzRIH8/MM8htDqGfxHFFQDMFXzl3h0AQJs4ZK7AJQBACIZbXOIWAOYK/j0OXAMAsolDLS5xDwAIgtzsEItLCMBqYAzIFZiHgABcOSPARypM5woIwI2UEGDzarOLSwjARk4QsKOZSQgIwJ2ksAcICMDOrADgQxambCIBEEwLAfY2NAMBARAAAJxS7m4TCcABAJakUett7bpCQAAOAgBaV9BtcQkBKABgpnUFBKAQAOCUsuq6AgJQAQAIgrymQO39AwJQCcAKgjw4zGsOaw5V8bkeoEaqr5NIDyGEmi3wu3zllBGgIQSFNrHrnsYEoDEAByHoKj4fAQDxV1nDvXcQTKwTYATAQpDHBbf2KzDzlVMCAARgwyaaEZ+PALD4q8dBjgRvFreiYwRQgsDqaQiAVWWUrosAKHW01dMQAKvKKF0XAVDqaKunIQBWlVG6LgKg1NFWT/MHv4lnn6K7Ir4AAAAASUVORK5CYII="
		},
		"1ffc": function(t, s, a) {
			"use strict";
			a("fd2c")
		},
		"37f9": function(t, s, a) {
			"use strict";
			a.r(s);
			var e = function() {
					var t = this,
						s = t._self._c;
					return s("div", [s("vue-particles", {
						attrs: {
							color: "#ffa4a7",
							particleOpacity: .9,
							particlesNumber: 150,
							shapeType: "star",
							particleSize: 4.5,
							linesColor: "#ffa4a7",
							linesWidth: 1,
							lineLinked: !1,
							lineOpacity: 0,
							linesDistance: 150,
							moveSpeed: 8,
							hoverEffect: !1,
							hoverMode: "repulse",
							clickEffect: !1,
							clickMode: "repulse"
						}
					}), s("div", {
						staticClass: "bg1"
					}), s("div", {
						staticClass: "bg2"
					}), s("div", {
						staticClass: "bg3"
					}), s("topTar", {
						attrs: {
							title: t.titleText,
							showBack: !t.showBtn1
						},
						on: {
							backHome: t.turnHome,
							set: t.setName
						}
					}), s("div", {
						directives: [{
							name: "show",
							rawName: "v-show",
							value: t.showBtn1,
							expression: "showBtn1"
						}],
						staticClass: "btn"
					}, [s("div", {
						staticClass: "btnBox"
					}, [s("van-button", {
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.showChildBtn("truth")
							}
						}
					}, [t._v("真心话大冒险")])], 1), s("div", {
						staticClass: "btnBox"
					}, [s("van-button", {
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.showChildBtn("plane")
							}
						}
					}, [t._v("情侣飞行棋")])], 1), s("div", {
						staticClass: "btnBox"
					}, [s("van-button", {
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.showChildBtn("dice")
							}
						}
					}, [t._v("摇骰子")])], 1)]), s("div", {
						directives: [{
							name: "show",
							rawName: "v-show",
							value: t.showBtn2,
							expression: "showBtn2"
						}],
						staticClass: "btn"
					}, [s("div", {
						staticClass: "btnBox"
					}, [s("van-button", {
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.toTruthVue(1)
							}
						}
					}, [t._v("温和版")]), s("div", {
						staticClass: "hot"
					}, [t._v("HOT")]), t.isPass ? t._e() : s("img", {
						staticClass: "lockIcon",
						attrs: {
							src: a("e1e6"),
							alt: ""
						}
					})], 1), s("div", {
						staticClass: "btnBox"
					}, [s("van-button", {
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.toTruthVue(2)
							}
						}
					}, [t._v("热辣版")]), s("div", {
						staticClass: "hot"
					}, [t._v("HOT")]), t.isPass ? t._e() : s("img", {
						staticClass: "lockIcon",
						attrs: {
							src: a("e1e6"),
							alt: ""
						}
					})], 1), s("div", {
						staticClass: "btnBox"
					}, [s("van-button", {
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.toTruthVue(3)
							}
						}
					}, [t._v("猛烈版")]), s("div", {
						staticClass: "hot"
					}, [t._v("HOT")]), t.isPass ? t._e() : s("img", {
						staticClass: "lockIcon",
						attrs: {
							src: a("e1e6"),
							alt: ""
						}
					})], 1), s("div", {
						staticClass: "btnBox"
					}, [s("van-button", {
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.toTruthVue(4)
							}
						}
					}, [t._v("极限版")]), s("div", {
						staticClass: "hot"
					}, [t._v("HOT")]), t.isPass ? t._e() : s("img", {
						staticClass: "lockIcon",
						attrs: {
							src: a("e1e6"),
							alt: ""
						}
					})], 1), s("div", {
						staticClass: "btnBox"
					}, [s("van-button", {
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.showAuto()
							}
						}
					}, [t._v("自定义名字")])], 1)]), s("div", {
						directives: [{
							name: "show",
							rawName: "v-show",
							value: t.showBtn3,
							expression: "showBtn3"
						}],
						staticClass: "btn"
					}, [s("div", {
						staticClass: "btnBox"
					}, [s("van-button", {
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.toPlaneVue(1)
							}
						}
					}, [t._v("基础模式")])], 1), s("div", {
						staticClass: "btnBox"
					}, [s("van-button", {
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.toPlaneVue(2)
							}
						}
					}, [t._v("恋爱版")])], 1), s("div", {
						staticClass: "btnBox"
					}, [s("van-button", {
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.toPlaneVue(3)
							}
						}
					}, [t._v("情侣版")]), s("div", {
						staticClass: "hot"
					}, [t._v("HOT")]), t.isPass ? t._e() : s("img", {
						staticClass: "lockIcon",
						attrs: {
							src: a("e1e6"),
							alt: ""
						}
					})], 1), s("div", {
						staticClass: "btnBox"
					}, [s("van-button", {
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.toPlaneVue(4)
							}
						}
					}, [t._v("高级版")]), s("div", {
						staticClass: "hot"
					}, [t._v("HOT")]), t.isPass ? t._e() : s("img", {
						staticClass: "lockIcon",
						attrs: {
							src: a("e1e6"),
							alt: ""
						}
					})], 1), s("div", {
						staticClass: "btnBox"
					}, [s("van-button", {
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.toPlaneVue(5)
							}
						}
					}, [t._v("私密版")]), s("div", {
						staticClass: "hot"
					}, [t._v("HOT")]), t.isPass ? t._e() : s("img", {
						staticClass: "lockIcon",
						attrs: {
							src: a("e1e6"),
							alt: ""
						}
					})], 1), s("div", {
						staticClass: "btnBox"
					}, [s("van-button", {
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.toPlaneVue(6)
							}
						}
					}, [t._v("组合模式")]), s("div", {
						staticClass: "hot"
					}, [t._v("HOT")]), t.isPass ? t._e() : s("img", {
						staticClass: "lockIcon",
						attrs: {
							src: a("e1e6"),
							alt: ""
						}
					})], 1), s("div", {
						staticClass: "btnBox"
					}, [s("van-button", {
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.toPlaneVue(7)
							}
						}
					}, [t._v("自定义")]), s("div", {
						staticClass: "hot"
					}, [t._v("HOT")]), t.isPass ? t._e() : s("img", {
						staticClass: "lockIcon",
						attrs: {
							src: a("e1e6"),
							alt: ""
						}
					})], 1)]), s("div", {
						directives: [{
							name: "show",
							rawName: "v-show",
							value: t.showBtn4,
							expression: "showBtn4"
						}],
						staticClass: "btn"
					}, [s("div", {
						staticClass: "btnBox"
					}, [s("van-button", {
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.toDiceVue(1)
							}
						}
					}, [t._v("初级模式")]), s("div", {
						staticClass: "hot"
					}, [t._v("HOT")]), t.isPass ? t._e() : s("img", {
						staticClass: "lockIcon",
						attrs: {
							src: a("e1e6"),
							alt: ""
						}
					})], 1), s("div", {
						staticClass: "btnBox"
					}, [s("van-button", {
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.toDiceVue(2)
							}
						}
					}, [t._v("进阶模式")]), s("div", {
						staticClass: "hot"
					}, [t._v("HOT")]), t.isPass ? t._e() : s("img", {
						staticClass: "lockIcon",
						attrs: {
							src: a("e1e6"),
							alt: ""
						}
					})], 1), s("div", {
						staticClass: "btnBox"
					}, [s("van-button", {
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.toDiceVue("auto")
							}
						}
					}, [t._v("自定义")]), s("div", {
						staticClass: "hot"
					}, [t._v("HOT")]), t.isPass ? t._e() : s("img", {
						staticClass: "lockIcon",
						attrs: {
							src: a("e1e6"),
							alt: ""
						}
					})], 1)]), s("div", {
						directives: [{
							name: "show",
							rawName: "v-show",
							value: t.showBtn5,
							expression: "showBtn5"
						}],
						staticClass: "btn"
					}, [s("div", {
						staticClass: "btnBox"
					}, [s("van-button", {
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.toTableVue(1)
							}
						}
					}, [t._v("基础模式")]), s("div", {
						staticClass: "hot"
					}, [t._v("HOT")]), t.isPass ? t._e() : s("img", {
						staticClass: "lockIcon",
						attrs: {
							src: a("e1e6"),
							alt: ""
						}
					})], 1), s("div", {
						staticClass: "btnBox"
					}, [s("van-button", {
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.toTableVue("auto")
							}
						}
					}, [t._v("自定义")]), s("div", {
						staticClass: "hot"
					}, [t._v("HOT")]), t.isPass ? t._e() : s("img", {
						staticClass: "lockIcon",
						attrs: {
							src: a("e1e6"),
							alt: ""
						}
					})], 1)]), s("van-popup", {
						model: {
							value: t.showGame,
							callback: function(s) {
								t.showGame = s
							},
							expression: "showGame"
						}
					}, [s("div", {
						staticClass: "iptBox"
					}, [t._l(t.gameList, (function(e, o) {
						return s("div", {
							key: o,
							staticClass: "setBox"
						}, [s("div", {
							staticClass: "gameBox",
							on: {
								click: function(s) {
									return t
										.toGameList(
											o)
								}
							}
						}, [s("div", {
							staticStyle: {
								"font-weight": "700"
							}
						}, [t._v(t._s(e.name))]), s(
							"div", {
								staticClass: "noPass"
							}, [s("img", {
								attrs: {
									src: a(
										"16de"),
									alt: ""
								}
							})])])])
					})), s("button", {
						staticClass: "iptBtn",
						staticStyle: {
							margin: "0.2rem"
						},
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.newGame("plane")
							}
						}
					}, [t._v("新建")])], 2)]), s("van-popup", {
						model: {
							value: t.showTable,
							callback: function(s) {
								t.showTable = s
							},
							expression: "showTable"
						}
					}, [s("div", {
						staticClass: "iptBox"
					}, [t._l(t.tableList, (function(e, o) {
						return s("div", {
							key: o,
							staticClass: "setBox"
						}, [s("div", {
							staticClass: "gameBox",
							on: {
								click: function(s) {
									return t
										.toTableList(
											o)
								}
							}
						}, [s("div", {
							staticStyle: {
								"font-weight": "700"
							}
						}, [t._v(t._s(e.name))]), s(
							"div", {
								staticClass: "noPass"
							}, [s("img", {
								attrs: {
									src: a(
										"16de"),
									alt: ""
								}
							})])])])
					})), s("button", {
						staticClass: "iptBtn",
						staticStyle: {
							margin: "0.2rem"
						},
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.newGame("table")
							}
						}
					}, [t._v("新建")])], 2)]), s("van-popup", {
						model: {
							value: t.showDice,
							callback: function(s) {
								t.showDice = s
							},
							expression: "showDice"
						}
					}, [s("div", {
						staticClass: "iptBox"
					}, [t._l(t.diceList, (function(e, o) {
						return s("div", {
							key: o,
							staticClass: "setBox"
						}, [s("div", {
							staticClass: "gameBox",
							on: {
								click: function(s) {
									return t
										.toDiceList(
											o)
								}
							}
						}, [s("div", {
							staticStyle: {
								"font-weight": "700"
							}
						}, [t._v(t._s(e.name))]), s(
							"div", {
								staticClass: "noPass"
							}, [s("img", {
								attrs: {
									src: a(
										"16de"),
									alt: ""
								}
							})])])])
					})), s("button", {
						staticClass: "iptBtn",
						staticStyle: {
							margin: "0.2rem"
						},
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.newGame("dice")
							}
						}
					}, [t._v("新建")])], 2)]), s("van-popup", {
						model: {
							value: t.showPassword,
							callback: function(s) {
								t.showPassword = s
							},
							expression: "showPassword"
						}
					}, [s("div", {
						staticClass: "iptBox"
					}, [s("div", {
						staticClass: "iptTitle"
					}, [t._v("关注公众号(风龙龙)"), s("br"), t._v("点击蓝色字体获取识别码")]), s(
						"input", {
							directives: [{
								name: "model",
								rawName: "v-model",
								value: t.password,
								expression: "password"
							}],
							staticClass: "ipt",
							attrs: {
								type: "password",
								placeholder: "请输入识别码",
								maxlength: "6",
								oninput: "value=value.replace(/[^\\d]/g,'')"
							},
							domProps: {
								value: t.password
							},
							on: {
								input: function(s) {
									s.target.composing || (t.password = s
										.target.value)
								}
							}
						}), s("button", {
						staticClass: "iptBtn",
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.toPassword()
							}
						}
					}, [t._v("确认")])])]), s("van-popup", {
						model: {
							value: t.showErrorTip,
							callback: function(s) {
								t.showErrorTip = s
							},
							expression: "showErrorTip"
						}
					}, [s("div", {
						staticClass: "iptBox"
					}, [s("div", {
						staticClass: "iptTitle"
					}, [t._v("该识别码" + t._s(t.password) + "已使用或不存在")]), s(
					"div", {
						staticClass: "errorTip"
					}, [t._v(
						"请注意，识别码只能使用一次，使用次之后再次使用会失效; 错误消息:校验验码失败，该核验码非有效核验码或者不存在!，请关注公众号风龙龙获取识别码!"
						)]), s("button", {
						staticClass: "iptBtn",
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.hideErrorTip()
							}
						}
					}, [t._v("确认")])])]), s("van-popup", {
						model: {
							value: t.showSuccess,
							callback: function(s) {
								t.showSuccess = s
							},
							expression: "showSuccess"
						}
					}, [s("div", {
						staticClass: "iptBox"
					}, [s("div", {
						staticClass: "iptTitle",
						staticStyle: {
							margin: "0.5rem 0 0.3rem 0"
						}
					}, [t._v("激活成功！")]), s("div", {
						staticClass: "errorTip"
					}, [t._v(
						"换设备或取关公众号等因素会导致识别码需重新输入 每个识别码仅限重输三次 三次后自动销毁 需要重新购买"
						)]), s("button", {
						staticClass: "iptBtn",
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.hideSuccess()
							}
						}
					}, [t._v("确认")])])]), s("van-popup", {
						model: {
							value: t.showGG,
							callback: function(s) {
								t.showGG = s
							},
							expression: "showGG"
						}
					}, [s("div", {
						staticClass: "iptBox"
					}, [s("div", {
						staticClass: "iptTitle",
						staticStyle: {
							margin: "0.5rem 0 0.3rem 0"
						}
					}, [t._v("公告")]), s("div", {
						staticClass: "errorTip"
					}, [t._v(" 新游戏[情趣骰子]已上线，识别码可畅玩所有游戏及版本。后期会持续更新更多情趣游戏。"),
						s("br"), t._v(
							" 注意：识别码会因某些因素掉绑，所以设置识别码仅可使用三次，使用过后请妥善保管，平台售出之后不会留存记录以免重新出售，使用三次后自动销毁，需重新购买。"
							), s("br"), t._v(" 识别码获取地址:公众号【风龙龙】 ")
					]), s("button", {
						staticClass: "iptBtn",
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.hideGG()
							}
						}
					}, [t._v("确认")])])]), s("van-popup", {
						model: {
							value: t.showSet,
							callback: function(s) {
								t.showSet = s
							},
							expression: "showSet"
						}
					}, [s("div", {
						staticClass: "iptBox"
					}, [s("div", {
						staticClass: "setBox"
					}, [s("div", {
						staticStyle: {
							"font-weight": "700"
						}
					}, [t._v("识别码")]), t.isPass ? s("div", [t._v(
						"已激活")]) : s("div", {
						staticClass: "noPass",
						on: {
							click: function(s) {
								return t.showPasd()
							}
						}
					}, [t._v("未激活 "), s("img", {
						attrs: {
							src: a("16de"),
							alt: ""
						}
					})])])])]), s("van-popup", {
						model: {
							value: t.showSetName,
							callback: function(s) {
								t.showSetName = s
							},
							expression: "showSetName"
						}
					}, [s("div", {
						staticClass: "iptBox"
					}, [s("div", {
						staticClass: "iptTitle",
						staticStyle: {
							margin: "0.5rem"
						}
					}, [t._v("自定义编辑名称")]), s("van-field", {
						staticClass: "humenipt",
						attrs: {
							label: "男生昵称"
						},
						model: {
							value: t.boy,
							callback: function(s) {
								t.boy = s
							},
							expression: "boy"
						}
					}), s("van-field", {
						staticClass: "humenipt",
						attrs: {
							label: "女生昵称"
						},
						model: {
							value: t.girl,
							callback: function(s) {
								t.girl = s
							},
							expression: "girl"
						}
					}), s("button", {
						staticClass: "iptBtn",
						staticStyle: {
							margin: "0.5rem 0 0.3rem 0"
						},
						attrs: {
							type: "default"
						},
						on: {
							click: function(s) {
								return t.putName()
							}
						}
					}, [t._v("确认")])], 1)])], 1)
				},
				o = [],
				i = (a("e7e5"), a("d399")),
				n = (a("14d9"), function() {
					var t = this,
						s = t._self._c;
					return s("div", [s("div", {
						staticClass: "title"
					}, [s("img", {
						directives: [{
							name: "show",
							rawName: "v-show",
							value: t.showBack,
							expression: "showBack"
						}],
						staticClass: "topIcon back_icon",
						attrs: {
							src: a("16de"),
							alt: ""
						},
						on: {
							click: function(s) {
								return t.backHome()
							}
						}
					}), s("span", [t._v(t._s(t.title))]), s("img", {
						staticClass: "topIcon set_icon",
						attrs: {
							src: a("48d7"),
							alt: ""
						},
						on: {
							click: function(s) {
								return t.set()
							}
						}
					})])])
				}),
				A = [],
				c = {
					namr: "toptar",
					components: {},
					props: {
						title: String,
						showBack: Boolean
					},
					data() {
						return {}
					},
					computed: {},
					watch: {},
					created() {},
					mounted() {},
					methods: {
						backHome() {
							this.$emit("backHome")
						},
						set() {
							this.$emit("set")
						}
					}
				},
				l = c,
				r = (a("1ffc"), a("2877")),
				h = Object(r["a"])(l, n, A, !1, null, "7efdb280", null),
				u = h.exports,
				d = {
					components: {
						topTar: u
					},
					data() {
						return {
							showBtn1: !0,
							showBtn2: !1,
							showBtn3: !1,
							showBtn4: !1,
							showBtn5: !1,
							titleText: "游戏 v 2.0.5",
							value: "123",
							showPassword: !1,
							showErrorTip: !1,
							showSuccess: !1,
							showSet: !1,
							showSetName: !1,
							showGG: !1,
							showGame: !1,
							showDice: !1,
							showTable: !1,
							password: "",
							isPass: localStorage.getItem("pass") || !1,
							boy: "",
							girl: "",
							gameList: JSON.parse(localStorage.getItem("gameList")) || [],
							diceList: JSON.parse(localStorage.getItem("diceList")) || [],
							tableList: JSON.parse(localStorage.getItem("tableList")) || []
						}
					},
					mounted() {
						console.log("this.$route.query", this.$route.query, this.$route.params), this.$route
							.params && "2" === this.$route.params.btn ? (this.showBtn1 = !1, this
								.showBtn2 = !0) : this.$route.params && "3" === this.$route.params.btn ? (
								this.showBtn1 = !1, this.showBtn3 = !0) : this.$route.params && "4" === this
							.$route.params.btn ? (this.showBtn1 = !1, this.showBtn4 = !0) : this.$route
							.params && "5" === this.$route.params.btn ? (this.showBtn1 = !1, this
								.showBtn5 = !0) : (this.showBtn1 = !0, this.showBtn2 = !1, this.showBtn3 = !
								1, this.showBtn4 = !1, this.showBtn5 = !1, this.showGG = !0)
					},
					methods: {
						showChildBtn(t) {
							switch (t) {
								case "truth":
									this.showBtn1 = !1, this.showBtn2 = !0;
									break;
								case "plane":
									this.showBtn1 = !1, this.showBtn3 = !0;
									break;
								case "dice":
									this.showBtn1 = !1, this.showBtn4 = !0;
									break;
								case "turnTable":
									this.showBtn1 = !1, this.showBtn5 = !0;
									break;
								default:
									break
							}
						},
						turnHome() {
							this.showBtn1 = !0, this.showBtn2 = !1, this.showBtn3 = !1, this.showBtn4 = !1,
								this.showBtn5 = !1, this.titleText = "伊甸园游戏 v 2.0.5"
						},
						setName() {
							this.showSet = !0
						},
						showPasd() {
							this.showSet = !1, this.showPassword = !0
						},
						putName() {
							this.boy && localStorage.setItem("boy", this.boy), this.girl && localStorage
								.setItem("girl", this.girl), this.showSetName = !1, Object(i["a"])("设置成功")
						},
						toTruthVue(t) {
							localStorage.getItem("pass") ? this.$router.push({
								path: "/truthOrDare/" + t
							}) : this.showPassword = !0
						},
						toPlaneVue(t) {
							if (localStorage.getItem("pass") && 7 == t) return this.gameList = JSON.parse(
								localStorage.getItem("gameList")) || [], void(0 !== this.gameList
								.length ? this.showGame = !0 : this.$router.push({
									path: "/setPlane"
								}));
							localStorage.getItem("pass") || 1 === t || 2 === t ? this.$router.push({
								path: "/plane/" + t
							}) : this.showPassword = !0
						},
						toDiceVue(t) {
							if (localStorage.getItem("pass") && "auto" == t) return this.diceList = JSON
								.parse(localStorage.getItem("diceList")) || [], void(0 !== this.diceList
									.length ? this.showDice = !0 : this.$router.push({
										path: "/setDice"
									}));
							localStorage.getItem("pass") ? this.$router.push({
								path: "/dice/" + t
							}) : this.showPassword = !0
						},
						toTableVue(t) {
							if (localStorage.getItem("pass") && "auto" == t) return this.tableList = JSON
								.parse(localStorage.getItem("tableList")) || [], void(0 !== this
									.tableList.length ? this.showTable = !0 : this.$router.push({
										path: "/setTable"
									}));
							localStorage.getItem("pass") ? this.$router.push({
								path: "/turnTable/" + t
							}) : this.showPassword = !0
						},
						newGame(t) {
							"dice" === t ? (this.showDice = !1, this.$router.push({
								path: "/setDice"
							})) : "plane" === t ? (this.showGame = !1, this.$router.push({
								path: "/setPlane"
							})) : "table" === t && (this.showGame = !1, this.$router.push({
								path: "/setTable"
							}))
						},
						toGameList(t) {
							this.$router.push({
								path: "/plane/7-" + t
							})
						},
						toDiceList(t) {
							this.$router.push({
								path: "/dice/auto-" + t
							})
						},
						toTableList(t) {
							this.$router.push({
								path: "/turnTable/auto-" + t
							})
						},
						showAuto() {
							this.showSetName = !0
						},
						hideErrorTip() {
							this.showErrorTip = !1
						},
						hideSuccess() {
							this.showSuccess = !1
						},
						hideGG() {
							this.showGG = !1
						},
						toPassword() {
							if (this.password.length < 6) Object(i["a"])("识别码为六位数字");
					
								
							}
						}
					}
				},
				p = d,
				w = (a("44cc"), Object(r["a"])(p, e, o, !1, null, "3abdca92", null));
			s["default"] = w.exports
		},
		"44cc": function(t, s, a) {
			"use strict";
			a("46aa")
		},
		"46aa": function(t, s, a) {},
		"48d7": function(t, s) {
			t.exports =
				"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAAAXNSR0IArs4c6QAAC6ZJREFUeF7tXYuR3TYMlCpJXEnsShJXEruS2JX4XEmcSpSBTN7wZIlYEAtST0+e8fhzEj/AYgmAIDVP96+nlsD81LO/Jz/dAHhyENwAuAHw5BJ48unfDHAD4Mkl8OTTvxngBsC1JLAsy+/TNP0bOKsP8zy/BLbftenLMcCyLO+nafoWKMWP8zx/CWy/a9NXBMBf0zT9EyjFGwCBwnU3vSzL39M0fXI3dNzAp3mePwe237XpKzLADQADhK4IAKF/WQaifn2Z5/ljVOO9270iAMQBFEcw6tcNgCjJMtpdliUaAC/zPH9gjPUMbQxngBS2/TlN0+d5nn94hbIsy1JrY57ndc4pX7B9VHII8rsWRdAAkOb+gzHvVrkNBcCyLGXIJskVCbGaQbBpb08mIux3NWGBiaR3nnEmAOZ8hcxXkkvN825Vvrw3DAAHyjILI7XzB+j4sQAgshPAfpU/rcrbCVXN8/YovXx3CAAUS1WFUSwbYkVC2egviL61ZWSnMwGD5AZUOq/4KOq80UlanusOAICm8/h/ybglxUuc3+rlowCQvQQLsPKYD1khLS3iW9TG3h0EXQGwLIs1Rl+zbgTFZwVBIdyyLK0AKIEgTu26aWTcn3D7QqdkgAbl53mIVbRY454coDQuAQAlEESh1tR0NxB0YQCH8i1gRp5FARCdS0DGKjuOlNC4GhYjI/E8cwLliyC/W7z1RNkSWWQnk8VAVlEKc3y1RhmWTkIZoENWbm+uZoVrAnNEHVrTyM9DQRAGAKPyvev8qvQehRoFO0gSqxczQEsXgqbtMyEAMCp/Dc0al4ou6+SRYAtmaN19lPGj74aAgA6AFuVnAacMGWJZQxW/BURDmCqMJ3mOF2MBCx0EVAB4lF+AQAAgyZ49ej2V4g+AILmO2tLwSzJqJAhoADAqv5qQSRZVCnJNtT5KNW7Kdu6B+NCCR4GAAgCm8gsmECuSeFzA8pA1eBu/Ri0nHwECNwAMuX3RLZSKbfFmz/pOYrMJZa/eIHADIOW60ULM7psdZwVGbVwGRoU2t7pkAg3IvUFQ0YiBUd3Kl2FQGKBYt9FdNHo484iWfhBFIKea1MIWVB5sAGTHDcmQ3SAotGTYMn7NIaBK7rIE7HjvCAgudcyqVSFgHWJuXo0mLOOgMkBDRk9ecRdYWiZ8tmeT8oX2EYOhKp/uA5TCNeT26ZM6m5IVjx+tkgpZMkMYIIWGiEPYLS+QLE3OH+Ta//xnLseWP/PfZQ++yx0AYPRE8fj3gBgCANChoXmyexMrFC5FHS1FpAIGAUH4NjNYghayVEYBALH+EEozJqbQ1ULAEJaS3tn72BtXCFvSAQBSWoj1g32jSt97LgwIoM9EZ4EIACDWT3X8wJp7j+K379KzmWA0QGcBKgBAC6RavzGGPjsIkIiAygJsAHSdAOhsMpW+xwQ032AEC9AAAFoijcJOoPwSDDSHFmRRGgswAYBsCVMG7lD+6sSlcwLrQc7inoCcF5BcgTVspOXnQRag+VBMAGinaShrPyig0jrNnnuRQ0AKVHNfNMcQiAhoTEoBAEj/FJo0FEuIYlx9FkBAz/axQI7cdUhhUxUAiW7zRsVvCe7535k25b+1zQw3bRmKJWiUnBJLlm1uyg4nkB2k9IMAoHrnDuhisywDyTFQ+trOy7D0UPoHma7cvyj//l+xr1G9tKIXAFxUnKwQoUXaOlzZX0C2bt3WCUYDiP1Vl4peAGDQP8JE7n40iYL+jpsFHJHOdgrDAcAQBmL9bpbRlJ9/Dvoi7vEAfgAy5OEAcO9lA2GR1N2rbIZIC3kG9Ae6zBsY73AAMCxBo3/3mgsI8s0jAAv0Yj5t6EMAUHqk0Zc/drX+YhlAvkzi8klIfkA4ANYbLEQwEVeZAPRPy4ppprQTGmrZTwb7lYdMy/wLknuRZ8IB4EK5JnQAAN3p3+AMuv0AQD7a8hgOAEpK8miiQEIkFIA1BQAUfQNAQ7D2cyAUCgWgAgDND3A7gs7+uywBoQrQ7u3tGf4dpIdrn6i7AaBZuPbzMwNAxj5yfEhWUjMQNXkycoJJwNoGUCgDOSl4OANcAQBaqPW0TuCzMIAGAHesrS1DlQhF26MIzVEAUYiaJHMvAUk45fk6+a/y3667boFt0fBQyxGiPg0AakbkWqMBlIeus4oPoCVhXMtTonjJBJZZv202sEpg4T4AQJ+uTB2yzqVbN7t+0BnYDFLpV5MdwH5aE+oYWEtAbSBuGgSygd1ZAEhQ9Zj3QwDAvUYj1tbzDkLQMl3Mh+QYVO3/3KCrGnkPBlDTkdpEwAIMaiVwxfHL3/tzrb3gnGtZRq2J9ednAQDDGrSQK0cfYR9hBP0RGQdjvshJKxUEDADkY1LifZbnAixnAhjLAFqbH1IZbDmCrgld1drPFLOWAUWa8TMA0gu4RrvCwbQmIiyQmUBuF6dEBkAoWoqJYf3aLmPuL99jtM3DyLmAVQ7aXUeqD4AAIClHQyxLMNrHF/OQzWcC9+YKOnyvCmF8WRzs021Qq4+AKlh7DqjccYdFCWjoUtAMhIYzgdnaqh+m1mSYf94z7GUCAPGOKag1OGOlzHOhqtQvrn/fOR6ePxVnPR4u/biyfoXyEfqn7X/QAAAuA7SBg34HanTe5yjKTzJUvX+Gk5knzAZA7ytiVGF5NQu8z1Q+Yv3UrCcbAMgyQGOBRp8A0Cn0CD3xBDp/VPlRAZAU0pUFChCg0QGkXeUhd15j2z7o11CtnxoFFE5MdxYoQCD3+1iudbGCgRJaHoSbWuGLvEa1/hAAjGKBjRfNBkKY4pO8EKOhW38kAJAJSRbLdW6wZr6JUmUcEtqhn2fdCxuF7kM/WwemfenWHwaAhOohlHZAr3nfQsCgXRcv1i43hJ/puvgQ6w8DAOjNSv9hE7Mu7iOeBx0/GRoli7o3x4goAKH/p1d+Ysnad5K3+jr/EmDcNaMlUEZYL6tPA1tKl5RUejl2GgMY6Ez6v5VfaMEAAnqtAwUAYMlWnnIIlbEsclQ7YCSw+gPpS+q5BsA1ZBYAEI8/1JlxSeEEL48yIjcAgDqALF46fZ1Ab9QhjAABAwCyI4emX9f7hJC7hKyfXadqYmBjBoOiOIVuAKRwxrItq4JgE01Q17yeuk3OnYTFUMbTWONA2Y2kAKAFBEfp1QOPWCYr6VhJy1Kcn0ggJACLUeTKInX5a1A+pfydBgAGCIBaOEnPSrVvlzStFSTFYc69vYdDEFiVP88zpfZQ5kcFQCsILDX3SSmhG0lWxad5I3UQ8uib6uiRyg8BQAMIZI0XqtQ+OLGnl+H+gdFpe5MLMb5LL0IJA0ADCFqMrnxHGEF+QxGGt7Nkta3bzGVYjII+RPmhABgAgizYDIbvufTbq/A0F1nXW74o5u0+TPnhABgIgj12gPf4i+8k5XMCqKV6lb19P1T5XQBgdJDYAnwDBOTYlmFjJnKs0na48rsBwAECSRqhWUZNIZBAyQCQ5ajllBE0Vm3CyM/pYWCtU6PX+7plnChZwiwPFUPVR8YxHk1XohNxSF8aABVW/bM32K4AAJngMMWZvO/y/nwE5K9eN5JAAZJRtT5fFV8+lECAMFlX5XddAjYCOTpKDlFfkWotL6lQwYCcqWsEwK7iN3OWpaDGYkPqJLozQBbKTgEEpPytlhMrQOEZCADtnoM8BFXpO2M9OtruvjtBRf/BA8MAkJaDLGw3+kE/Qa2pAypzXMra2fN3tdeq+PzeUAAkELxnbe4AykMAULv9E3IkEaUkZ3N1FJHno54ZDgDmxBrXb8sQaACwdBr57NUAgO7Itcq0yU9p7azHezcAbFLuHqbZhmd/+gaATWZuZ9XWXfzTVwOApTaxRbo3AFqk1usdY3VNy7CGhmwtA9beuRoDoDeJanI5+vnljrRdDQDoyeQbAEkClwJAq1af+b0bAM+s/Yiy8CeX58NN/2aAh1MZd8A3ALjyfLjWbgA8nMq4A74BwJXnw7V2A+DhVMYd8P/FANnbS3O6IwAAAABJRU5ErkJggg=="
		},
		e1e6: function(t, s) {
			t.exports =
				"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAAAXNSR0IArs4c6QAABvNJREFUeF7tnVFS4zgQhrsd5hwbTkI4ycDThqpJWE4AnIABpgr2KZmTEE5C7rFgbSkhTJaNJdkjtVrxnxeYwbFaf39udcuyzLTHn5ubhyEd0HBgaGi4+sN21bAZVvbfhobENCRDS/v/zLSsef17VZtn+/ONaXkxOVvssUTE+9Y56/TqoPrKZEaGaPTb/XsHhJjnNdXP+wbEXgCwcToZc7K6qlN+LBB7BEPRANze/31JZK5S+tt57ncYzid/Xmez4TcbLhKAm/uHUWV4lvxqDxXX0JLJXE+nZ/PQr2g5rigAbKgfHPAsytiewgPGJpLmtKQ8oQgArOP5C1+yoZNoftvK/j8qgkgnN0xz84+5vrg4W1UVmj/qAViFe+KnTiK+j9H2uzaDtz9dV+eqbLSf99KxrvioM3SF5AeqAeiU5EXO0jdzCRVVR92qDL7SnCSqBeDu/vGp3VjPV/Vr/TN12P0oOVtUH0y0mE7Gx52iWOIvqQOgbaJnxX17NaepHf/ZD63zEpsgvpljaTt9/KgCoNV4ryTjbgWsEpu3oVADwDq08ouPWDt3r7Hmvrt7ODHEl965CWUQqAHg9u7xJUg8hWF0A+0K4gE/ldQPFQCEJHyaE6ntqBWcJBpank/Hh96Il/iA7ACEOJ9Idym1y0chJaydMPrr2/g0sY+dp88KQIhINZnjkqZWt9Ve5QXMM7eD88KdDYCQjJ+NOS3xBsu2w72QZ04KswHgS/pKGfNDwncIBLnygSwA+ELjPjnfAhIyV5Ar2mUBwHn1K8mOQ67sNsd4S8RM/RYHwBcOS076fED4JrtyVAUZAHg0TULlEMDntNh///7jcdZ4iznD/QJRAJydt/fsX82htpslsQHQFgXEAPB1vMTJnq5wOJNg4bJQDADf2H8+GYvZ0tVxsb7nTQgFZz7FRHdl/rlKoFgO7XIeXxSQmheQA+C+Ofnr09W/fefQtcJZqhoSAcBFex8y/6YI4U6KZe4RyADgWN8nRXqXMJ36O677IVKzoSIA3CL872TJWRkJzQwmBwDh3x1HXOshJKJjcgBc41wfs//POLiGAYn8KDkALsL7mP3/DwDHYliJPCA5AK76HwCscWjUSCAPyAaABN2ps/hY52+MknsBQEMFIDG+xXJQ6vPkHCaTRgBXmQMAfmHlSpRT3yFNC4Dz0W6Zma7UV2+M87tulKUuBZMC4JoDQAn4Cx2XTgAgxiWm/Bw5LxREAAVwAAAFTshpAgDIqb6CtgGAAifkNAEA5FRfQdsAQIETcpoAAHKqr6BtAKDACTlNAAA51VfQNgBQ4IScJgCAnOoraBsAKHBCThOKA+BjV22PaoMBjZo3SVrv7ZtTeC1tx9Kpy5PVwTeD7OrVAfFluw2ctUjcEzvsLqpMS0O8CN2h3AtAyP42PZG3qG6GvrTCC0DYRo5FadMbY0MW3joB8O3m1RslC+6ob+WVEwDfXn4F69If0z1Ly90AOB7q7I+C5ffU9QBOIwDOrVwNLU1Fe/1O3dLcvnofcsOrcl0LS7sBILiHTWmOyGVv16XlACCXxyK3CwAiC1ra6QBAaR6LbC8AiCxoaacDAKV5LLK9ACCyoKWdDgCU5rHI9gKAyIKWdjoAUJrHItsLACILWtrpAEBpHotsLwCILGhppwMALT1mBWMyI2NoSMzz0DV0LZsROxwAtJB61zK30nctAwAtAGjavTz1hkwtTGx9KAAIlCznjlyBJnY6DAAEypbzKZxAEzsdBgACZQMA/xWqdyuCAAAAOGl6XtG3hj4wyGQ5DENAoOyIAIgAiABbDCAH2BbDmNPp9GweGExUHYYhINAdGAIwBGAIwBDAs10BA1XAlirOZwMLfjQMQwCGAAwBGAIwBGwYQBmIMnB3/YQcILCuVHIY5gECHYEkEEkgkkAkgUgCkQTuGDIwEYSJINwM2jCAKiAwq1RyGKqAQEegCkAVgCoAVQCqAFQBqAJWCuBeAO4F9OtegKu6wTxAD+YB7BtQqgN+2YV9/WoOu7x3J7AASXoYysAW8u4SC4+HfxJwXyeCNt208wF1xUfrbdbDX7LUgjPRQxEBROXW1xgA0OcTUYsAgKjc+hoDAPp8ImoRABCVW19jAECfT0QtAgCicutrDADo84moRQBAVG59jQEAfT4RtQgAiMqtrzEAoM8nohYBAFG59TUmC4ChJTMt9cnQX4vW297TcJcCrnUOzUvCHAsn+itzmT3v9Pp429Vd++qXKUF/rWaixXQyPm5SoDECrAC4e2hcQ99fScvque8dCE4AbFe//3icsaGTsroNa60Cvqv//Ri3WOtFlNVXInMFWUtSgK9C3oPkjQCbLlsQ+AtfrtfQ0agkKXpjq6GlfQFWTfXzxeRsEdLvfwGCqp3qtS+vEAAAAABJRU5ErkJggg=="
		},
		fd2c: function(t, s, a) {}
	}
]);